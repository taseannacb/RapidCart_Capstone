﻿namespace RapidCart.Core.Enums
{
    public enum AppMode
    {
        Test,
        Live
    }
}