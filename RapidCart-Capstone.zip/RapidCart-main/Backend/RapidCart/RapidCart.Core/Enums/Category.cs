﻿namespace RapidCart.Core.Enums
{
    public enum Category
    {
        Beverages = 1,
        Bakery,
        CannedGoods,
        Dairy,
        BakingGoods,
        Frozen,
        Meat,
        Produce,
        Cleaners,  
        PaperGoods,
        PersonalCare,
        Other
    }
}