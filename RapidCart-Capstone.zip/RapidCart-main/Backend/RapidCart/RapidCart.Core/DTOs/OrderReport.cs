﻿using System.Collections.Generic;

namespace RapidCart.Core.DTOs
{
    public class OrderReport
    {
        List<Order> orders { get; set; }
    }
}